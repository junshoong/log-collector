```
chmod u+x ./setup.sh
./setup.sh
```
